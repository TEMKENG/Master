import {Shape, ShapeManager} from "./types.js";
import {ToolArea} from "./ToolArea.js";
import {setup} from "./script.js";

// export * from "./script.js";

export class Canvas implements ShapeManager {
    private readonly ctx: CanvasRenderingContext2D;
    private shapes: { [p: number]: Shape } = {};
    private width: number;
    private height: number;
    private selectShapes: number[] = [];
    private altIsPressed: boolean = false;
    private strgIsPressed: boolean = false;
    private iterator: number = 1;
    private selectColor = 'yellow';
    private state: number[] = [];

    constructor(canvasDomElement: HTMLCanvasElement,
                toolarea: ToolArea) {
        const {width, height} = canvasDomElement.getBoundingClientRect();
        this.width = width;
        this.height = height;

        this.ctx = canvasDomElement.getContext("2d");
        canvasDomElement.addEventListener("mousemove", createMouseHandler("handleMouseMove"));
        canvasDomElement.addEventListener("mousedown", createMouseHandler("handleMouseDown"));
        canvasDomElement.addEventListener("mouseup", createMouseHandler("handleMouseUp"));

        let self = this;
        document.addEventListener("keydown", function (e: KeyboardEvent) {
            self.altIsPressed = e.altKey;
            self.strgIsPressed = e.ctrlKey;
            if (e.keyCode === 46) {
                self.removeSelectedShapes();
            }
        });
        document.addEventListener("keyup", function (e: KeyboardEvent) {
            self.altIsPressed = false;
            self.strgIsPressed = false;
            self.iterator = 1;

        });
        document.addEventListener('contextmenu', ev => {
            ev.preventDefault();
            setup.menu.show(ev.clientX, ev.clientY);
        }, false);

        setup.menuEntries['Hintergrund'].forEach(entry => {
            entry.function = function () {
                for (let i = 0; i < self.selectShapes.length; i++) {
                    let id = self.selectShapes[i];
                    self.shapes[id].bgColor = entry.entry.value;
                    self.shapes[id].draw(self.ctx, true);
                }
            };
            entry.listener();
        });
        setup.menuEntries['Randfarbe'].forEach(entry => {
            entry.function = function () {
                for (let i = 0; i < self.selectShapes.length; i++) {
                    let id = self.selectShapes[i];
                    self.shapes[id].bdColor = entry.entry.value;
                    self.shapes[id].draw(self.ctx, true);
                }
            };
            entry.listener();
        });
        let [z_minus, z_plus] = setup.menuEntries['Z'];
        z_plus.function = function () {
            console.log('len: ', self.selectShapes.length);
            let len = self.selectShapes.length;
            for (let i = 0; i < self.selectShapes.length; i++) {
                let id = self.selectShapes[i];
                let index = self.state.indexOf(id);
                if (index !== self.state.length - 1) {
                    let next = self.state[index];
                    self.state[index] = self.state[index + 1];
                    self.state[index + 1] = next;
                    console.log('len: ', self.selectShapes.length, index);

                    // let shape = self.shapes[]
                    // self.shapes[id].draw(self.ctx, true);
                }
            }
            // let copy = deepCopy(self.shapes);
            // console.log('la copy '  , copy);
            // self.shapes = {};
            // for (let id of self.state){
            //     self.shapes[id] = copy[id];
            // }
            console.log('Draw puls: ', self.state, self.shapes);

        };
        // z_minus.function = function () {
        setup.menuEntries['Z'][0].function = function () {
            console.log('len: ', self.selectShapes.length);
            for (let i = 0; i < self.selectShapes.length; i++) {
                let id = self.selectShapes[i];
                let index = self.state.indexOf(id);
                if (index !== 0) {
                    let next = self.state[index];
                    self.state[index] = self.state[index - 1];
                    self.state[index - 1] = next;

                    // let shape = self.shapes[]
                    // self.shapes[id].draw(self.ctx, true);
                }
            }

            // let copy = deepCopy(self.shapes);
            // self.shapes = {};
            // for (let id of self.state){
            //     self.shapes[id] = copy[id];
            // }
            console.log('Draw minus: ', self.state, self.shapes);
        };
        z_plus.listener();
        z_minus.listener();
        function deepCopy<T>(o:T):T{
            return  JSON.parse(JSON.stringify(0));
        }
        console.log("menussssss:  ", setup.menuEntries['Hintergrund']);
        console.log("menussssss:  ", setup.menuEntries['Randfarbe']);
        console.log("menussssss:  ", setup.menuEntries['Delete']);
        console.log("menussssss:  ", setup.menuEntries['Z']);
        console.log("menussssss:  ", setup.menuEntries);

        console.log("Setup", setup);

        function createMouseHandler(methodName: string) {
            return function (e) {
                e = e || window.event;

                if ('object' === typeof e) {
                    const btnCode = e.button,
                        x = e.pageX - this.offsetLeft,
                        y = e.pageY - this.offsetTop,
                        ss = toolarea.getSelectedShape();
                    // if left mouse button is pressed,
                    // and if a tool is selected, do something
                    if (e.button === 0 && ss) {
                        const m = ss[methodName];
                        // This in the shapeFactory should be the factory itself.
                        m.call(ss, x, y);
                    }
                }
            }
        }

        for (let i = 0; i < setup.entries.length; i++) {
            // console.log('menuEntry: ', setup.menu.m.childNodes[i].id);
            if (setup.menu.m.childNodes[i].id === 'Delete') {
                // setup.entries[i].function = this.removeSelectedShapes;
                setup.entries[i].function = function () {
                    for (let index = 0; index < self.selectShapes.length; index++) {
                        self.removeShapeWithId(self.selectShapes[index]);
                    }
                    self.selectShapes = [];
                };

                setup.entries[i].listener();
                // console.log('TEMKENG tu dois bossé dur que maintenant!', setup.entries[i].function );
            }
        }


    }

    bgColor(color?: string) {
        for (let i = 0; i < this.selectShapes.length; i++) {
            let id = this.selectShapes[i];
            this.shapes[id].bgColor = color;
            this.shapes[id].draw(this.ctx, true);
        }
    }

    bdColor(color?: string) {
        for (let i = 0; i < this.selectShapes.length; i++) {
            let id = this.selectShapes[i];
            this.shapes[id].bdColor = color;
            this.shapes[id].draw(this.ctx, true);
        }
    }

    draw(): this {
        // TODO: it there a better way to reset the canvas?
        this.ctx.clearRect(0, 0, this.width, this.height);
        this.ctx.beginPath();
        this.ctx.fillStyle = 'lightgrey';
        this.ctx.fillRect(0, 0, this.width, this.height);
        this.ctx.stroke();

        // draw shapes
        this.ctx.fillStyle = 'black';
        // for (let id in this.shapes) {
        for (let id of this.state) {
            // console.log('Draw: ', typeof id, this.state, this.shapes);
            this.shapes[id].draw(this.ctx);
        }
        return this;
    }


    addShape(shape: Shape, redraw: boolean = true): this {
        this.shapes[shape.id] = shape;
        this.state.push(shape.id);
        return redraw ? this.draw() : this;
    }

    removeShape(shape: Shape, redraw: boolean = true): this {
        const id = shape.id;
        delete this.shapes[id];
        this.state = this.state.filter(item => item != id);
        return redraw ? this.draw() : this;
    }

    removeShapeWithId(id: number, redraw: boolean = true): this {
        delete this.shapes[id];
        this.state = this.state.filter(item => item != id);
        return redraw ? this.draw() : this;
    }

    removeSelectedShapes() {
        // console.log("hallo fromm remoi", this.selectShapes);
        for (let index = 0; index < this.selectShapes.length; index++) {
            this.removeShapeWithId(this.selectShapes[index]);
        }
        this.selectShapes = [];
    }

    chooseShapeAt(x: number, y: number, selected: boolean = false): this {
        this.ctx.clearRect(0, 0, this.width, this.height);
        let shapeUnderMouse: number[] = [];
        // console.log('State: ', this.state, this.shapes);
        // for (let id of Object.keys(this.shapes)) {
        // for of return genauer element of the list
        // for in return str element of the list
        for (let id of this.state) {
            // console.log('State: ', this.state, this.shapes, typeof id);
            if (this.shapes[id].isInside(x, y)) {
                shapeUnderMouse.push(id);
                this.shapes[id].draw(this.ctx, true, this.selectColor);

            } else {
                this.shapes[id].draw(this.ctx);
            }

        }

        if (selected && shapeUnderMouse.length > 0) {
            if (this.strgIsPressed) {
                this.selectShapes = shapeUnderMouse;
            } else if (this.selectShapes.length === 0) {
                this.selectShapes.push(shapeUnderMouse[shapeUnderMouse.length - 1]);
            } else {
                this.selectShapes = [];
                if (this.altIsPressed) {
                    this.iterator = (this.iterator + 1) % (shapeUnderMouse.length + 1) === 0 ? 1 : (this.iterator + 1) % (shapeUnderMouse.length + 1);
                }
                this.selectShapes.push(shapeUnderMouse[shapeUnderMouse.length - this.iterator]);
                // console.log("sle: ", shapeUnderMouse, this.selectShapes, this.iterator);
            }

        }

        for (let i = 0; i < this.selectShapes.length; i++) {
            // console.log("Selected: ", this.selectShapes, this.shapes);
            this.shapes[this.selectShapes[i]].draw(this.ctx, true, 'red');
        }

        return this;
    }
}

