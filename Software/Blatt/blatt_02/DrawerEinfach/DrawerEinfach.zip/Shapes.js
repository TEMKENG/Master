class Point2D {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
}
class AbstractShape {
    // static bdColor: string;
    // static bgColor: string;
    constructor() {
        this.id = AbstractShape.counter++;
        // AbstractShape.bgColor = undefined;
        // AbstractShape.bdColor = undefined;
    }
}
AbstractShape.counter = 0;
class AbstractFactory {
    constructor(shapeManager) {
        this.shapeManager = shapeManager;
    }
    handleMouseDown(x, y) {
        this.from = new Point2D(x, y);
    }
    handleMouseUp(x, y) {
        // remove the temp line, if there was one
        if (this.tmpShape) {
            this.shapeManager.removeShapeWithId(this.tmpShape.id, false);
        }
        this.shapeManager.addShape(this.createShape(this.from, new Point2D(x, y)));
        this.from = undefined;
    }
    handleMouseMove(x, y) {
        // show temp circle only, if the start point is defined;
        if (!this.from) {
            return;
        }
        if (!this.tmpTo || (this.tmpTo.x !== x || this.tmpTo.y !== y)) {
            this.tmpTo = new Point2D(x, y);
            if (this.tmpShape) {
                // remove the old temp line, if there was one
                this.shapeManager.removeShapeWithId(this.tmpShape.id, false);
            }
            // adds a new temp line
            this.tmpShape = this.createShape(this.from, new Point2D(x, y));
            this.shapeManager.addShape(this.tmpShape);
        }
    }
}
export class Line extends AbstractShape {
    constructor(from, to) {
        super();
        this.from = from;
        this.to = to;
    }
    draw(ctx, select, color = 'red') {
        ctx.beginPath();
        const oldStroke = ctx.strokeStyle;
        if (this.bdColor !== undefined) {
            ctx.strokeStyle = this.bdColor;
            // this.bdColor = undefined;
            // console.log("Line stroke bdColor: ", ctx.strokeStyle, oldStroke, this.bgColor);
        }
        else if (this.bgColor !== undefined) {
            ctx.strokeStyle = this.bgColor;
            // this.bgColor = undefined;
            // console.log("Line stroke: ", ctx.strokeStyle, oldStroke, this.bdColor);
        }
        ctx.moveTo(this.from.x, this.from.y);
        ctx.lineTo(this.to.x, this.to.y);
        ctx.stroke();
        if (select) {
            let points = [new Point2D(this.from.x, this.from.y), new Point2D(this.to.x, this.to.y)];
            selected_draw(ctx, points, color);
        }
        ctx.strokeStyle = oldStroke;
    }
    isInside(x, y) {
        const point = this.from.x <= this.to.x ? [this.from, this.to] : [this.to, this.from];
        const numerator = Math.abs((this.to.y - this.from.y) * x - (this.to.x - this.from.x) * y + this.to.x * this.from.y - this.to.y * this.from.x);
        const denominator = Math.sqrt(Math.pow((this.to.y - this.from.y), 2) + Math.pow((this.to.x - this.from.x), 2));
        return numerator / denominator < 10;
    }
}
export class LineFactory extends AbstractFactory {
    constructor(shapeManager) {
        super(shapeManager);
        this.label = "Linie";
    }
    createShape(from, to) {
        return new Line(from, to);
    }
}
class Circle extends AbstractShape {
    constructor(center, radius) {
        super();
        this.center = center;
        this.radius = radius;
    }
    draw(ctx, select, color = 'red') {
        ctx.beginPath();
        const oldStroke = ctx.strokeStyle;
        ctx.arc(this.center.x, this.center.y, this.radius, 0, 2 * Math.PI);
        if (this.bgColor !== undefined) {
            ctx.fillStyle = this.bgColor;
            ctx.fill();
        }
        if (this.bdColor !== undefined) {
            ctx.strokeStyle = this.bdColor;
            // ctx.stroke();
        }
        ctx.stroke();
        if (select) {
            let points = [new Point2D(this.center.x - this.radius, this.center.y + 3), new Point2D(this.center.x + this.radius, this.center.y + 3)];
            selected_draw(ctx, points, color);
        }
        ctx.strokeStyle = oldStroke;
    }
    isInside(x, y) {
        const area1 = Math.pow(x - this.center.x, 2) + Math.pow(y - this.center.y, 2);
        const area2 = Math.pow(this.radius, 2);
        return area1 - area2 <= 0;
    }
}
export class CircleFactory extends AbstractFactory {
    constructor(shapeManager) {
        super(shapeManager);
        this.label = "Kreis";
    }
    createShape(from, to) {
        return new Circle(from, CircleFactory.computeRadius(from, to.x, to.y));
    }
    static computeRadius(from, x, y) {
        const xDiff = (from.x - x), yDiff = (from.y - y);
        return Math.sqrt(xDiff * xDiff + yDiff * yDiff);
    }
}
class Rectangle extends AbstractShape {
    constructor(from, to) {
        super();
        this.from = from;
        this.to = to;
    }
    draw(ctx, select, color = 'red') {
        ctx.beginPath();
        const oldStroke = ctx.strokeStyle;
        if (this.bdColor !== undefined) {
            ctx.strokeStyle = this.bdColor;
        }
        ctx.strokeRect(this.from.x, this.from.y, this.to.x - this.from.x, this.to.y - this.from.y);
        // ctx.stroke();
        if (this.bgColor !== undefined) {
            ctx.fillStyle = this.bgColor;
            // console.log("bgColor: ", this.bgColor);
            ctx.fillRect(this.from.x, this.from.y, this.to.x - this.from.x, this.to.y - this.from.y);
            // ctx.fill();
            ctx.stroke();
        }
        // if (this.bdColor !== undefined) {
        //     ctx.strokeStyle = this.bdColor;
        //     // ctx.strokeRect(this.from.x, this.from.y, this.to.x - this.from.x, this.to.y - this.from.y);
        //     ctx.stroke();
        // }
        if (select) {
            let points = [new Point2D(this.from.x, this.to.y), new Point2D(this.from.x, this.from.y), new Point2D(this.to.x, this.to.y), new Point2D(this.to.x, this.from.y)];
            selected_draw(ctx, points, color);
        }
        ctx.strokeStyle = oldStroke;
    }
    isInside(x, y) {
        return (x >= this.from.x && x <= this.to.x && y >= this.from.y && y <= this.to.y);
    }
}
export class RectangleFactory extends AbstractFactory {
    constructor(shapeManager) {
        super(shapeManager);
        this.label = "Rechteck";
    }
    createShape(from, to) {
        return new Rectangle(from, to);
    }
}
class Triangle extends AbstractShape {
    constructor(p1, p2, p3) {
        super();
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }
    draw(ctx, select, color = 'red') {
        ctx.beginPath();
        const oldStroke = ctx.strokeStyle;
        ctx.moveTo(this.p1.x, this.p1.y);
        ctx.lineTo(this.p2.x, this.p2.y);
        ctx.lineTo(this.p3.x, this.p3.y);
        ctx.lineTo(this.p1.x, this.p1.y);
        if (this.bgColor !== undefined) {
            ctx.fillStyle = this.bgColor;
            ctx.fill();
        }
        if (this.bdColor !== undefined) {
            ctx.strokeStyle = this.bdColor;
            // ctx.stroke();
        }
        ctx.stroke();
        if (select) {
            let points = [new Point2D(this.p1.x, this.p1.y), new Point2D(this.p2.x, this.p2.y), new Point2D(this.p3.x, this.p3.y)];
            selected_draw(ctx, points, color);
        }
        ctx.strokeStyle = oldStroke;
    }
    ABxAC(a, b, c) {
        const ab = new Point2D(b.x - a.x, b.y - a.y);
        const ac = new Point2D(c.x - a.x, c.y - a.y);
        return ab.x * ac.y - ab.y * ac.x;
    }
    isInside(x, y) {
        const p = new Point2D(x, y);
        const a = this.ABxAC(this.p1, this.p2, p) <= 0;
        const b = this.ABxAC(this.p2, this.p3, p) <= 0;
        const c = this.ABxAC(this.p3, this.p1, p) <= 0;
        return a === b && b === c;
    }
}
export class TriangleFactory {
    constructor(shapeManager) {
        this.shapeManager = shapeManager;
        this.label = "Dreieck";
    }
    handleMouseDown(x, y) {
        if (this.tmpShape) {
            this.shapeManager.removeShapeWithId(this.tmpShape.id, false);
            this.shapeManager.addShape(new Triangle(this.from, this.tmpTo, new Point2D(x, y)));
            this.from = undefined;
            this.tmpTo = undefined;
            this.tmpLine = undefined;
            this.thirdPoint = undefined;
            this.tmpShape = undefined;
        }
        else {
            this.from = new Point2D(x, y);
        }
    }
    handleMouseUp(x, y) {
        // remove the temp line, if there was one
        if (this.tmpLine) {
            this.shapeManager.removeShapeWithId(this.tmpLine.id, false);
            this.tmpLine = undefined;
            this.tmpTo = new Point2D(x, y);
            this.thirdPoint = new Point2D(x, y);
            this.tmpShape = new Triangle(this.from, this.tmpTo, this.thirdPoint);
            this.shapeManager.addShape(this.tmpShape);
        }
    }
    handleMouseMove(x, y) {
        // show temp circle only, if the start point is defined;
        if (!this.from) {
            return;
        }
        if (this.tmpShape) { // second point already defined, update temp triangle
            if (!this.thirdPoint || (this.thirdPoint.x !== x || this.thirdPoint.y !== y)) {
                this.thirdPoint = new Point2D(x, y);
                if (this.tmpShape) {
                    // remove the old temp line, if there was one
                    this.shapeManager.removeShapeWithId(this.tmpShape.id, false);
                }
                // adds a new temp triangle
                this.tmpShape = new Triangle(this.from, this.tmpTo, this.thirdPoint);
                this.shapeManager.addShape(this.tmpShape);
            }
        }
        else { // no second point fixed, update tmp line
            if (!this.tmpTo || (this.tmpTo.x !== x || this.tmpTo.y !== y)) {
                this.tmpTo = new Point2D(x, y);
                if (this.tmpLine) {
                    // remove the old temp line, if there was one
                    this.shapeManager.removeShapeWithId(this.tmpLine.id, false);
                }
                // adds a new temp line
                this.tmpLine = new Line(this.from, this.tmpTo);
                this.shapeManager.addShape(this.tmpLine);
            }
        }
    }
}
export class ChooseShape {
    constructor(shapeManager) {
        this.shapeManager = shapeManager;
        this.label = "Auswahl";
    }
    handleMouseDown(x, y) {
    }
    handleMouseUp(x, y) {
        this.shapeManager.chooseShapeAt(x, y, true);
    }
    handleMouseMove(x, y) {
        this.shapeManager.chooseShapeAt(x, y);
    }
}
function selected_draw(ctx, points, color) {
    const oldStroke = ctx.strokeStyle;
    const oldFillStroke = ctx.fillStyle;
    for (let i = 0; i < points.length; i++) {
        ctx.beginPath();
        ctx.fillStyle = color;
        ctx.fillRect(points[i].x - 3, points[i].y - 3, 6, 6);
        ctx.stroke();
    }
    ctx.fillStyle = oldFillStroke;
    ctx.strokeStyle = oldStroke;
}
//# sourceMappingURL=Shapes.js.map